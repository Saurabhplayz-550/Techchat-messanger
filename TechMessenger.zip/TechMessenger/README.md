# Tech Messenger

Ek WhatsApp jaisa Android app (Kotlin) — abhi ke liye sirf **Login / Sign Up / OTP verification** system hai, Supabase backend ke saath (`techchat-music` project, already configured).

Package name: `com.techchat.messanger`

---

## 1. GitHub par kaise daalein (Android Studio ki zaroorat nahi)

1. GitHub.com par ek naya **empty repository** banayein (README/gitignore ADD mat karein, kyunki yeh project apne saath laata hai).
2. Is poore folder (jo aapko zip me mila hai) ko apne computer/phone me ek baar extract karein.
3. Us folder ko naye repo me push kar dein. Sabse aasan tareeka:
   - **GitHub Desktop app** (Windows/Mac) — folder select karke "Publish repository" dabayein.
   - Ya command line se:
     ```
     git init
     git add .
     git commit -m "Initial commit"
     git branch -M main
     git remote add origin https://github.com/<aapka-username>/<repo-name>.git
     git push -u origin main
     ```
4. Push hote hi **GitHub Actions apne aap chalu ho jaayega** aur APK build karega — Android Studio khud install karne ki zaroorat nahi.

## 2. APK kaise download karein

1. GitHub repo par jaayein → **Actions** tab.
2. "Build APK" workflow (green tick ✅) par click karein.
3. Neeche **Artifacts** section me `tech-messenger-debug-apk` milega — usko download karke apne phone me install kar lein (Unknown sources allow karna padega).

Build me 3-5 minute lagte hain. Agar laal ❌ cross aaye, "build" job kholkar error dekh sakte hain — zyadatar chhoti library-version dikkatein hoti hain jo aasani se fix ho jaati hain.

---

## 3. Supabase Dashboard me 2 zaroori settings (Free)

Backend (database, tables, storage) already ban chuka hai. Bas yeh 2 cheezein Supabase Dashboard (supabase.com → aapka project `techchat-music`) me manually karni hain, kyunki yeh email/SMS template settings hain:

### A) Email OTP code dikhna (free, already built-in)
- **Authentication → Email Templates → Confirm signup**
- Template me link (`{{ .ConfirmationURL }}`) ki jagah OTP code dikhayein:
  ```html
  <h2>Your Tech Messenger code</h2>
  <p>Enter this code in the app: <strong>{{ .Token }}</strong></p>
  ```
- Save karein. Ab jab koi email se sign up karega, usko ek 6-digit code milega.

### B) Phone (SMS) OTP — isme paisa lagta hai
Supabase khud SMS nahi bhejta — usko ek SMS provider chahiye (Twilio, MessageBird, Vonage, ya Textlocal). Free me sirf **trial credit** milta hai:
- **Authentication → Providers → Phone** ko enable karein.
- Twilio par free trial account banayein (https://www.twilio.com/try-twilio) — kuch free credit milta hai jisse testing ke liye kaafi SMS bhej sakte hain.
- Twilio ka Account SID, Auth Token, aur Messaging Service SID Supabase ke Phone provider settings me daal dein.
- Trial credit khatam hone ke baad SMS bhejne ke liye paisa lagega — yeh Supabase ki limitation nahi, SMS carriers ki cost hai.

Jab tak yeh setup nahi karte, app me **email se sign up/login free me pura chalega**; phone number se sign up karne par OTP tab tak nahi jaayega jab tak Twilio connect na ho.

---

## 4. App me kya kaam karta hai

- **Splash screen** → agar already logged in hai to seedha Home, warna Login par le jaata hai.
- **Login**: Email, Username, ya Phone number + Password — teeno se login ho sakta hai.
- **Sign Up**: Profile pic, Username, Full name, Email ya Phone number, Password, Confirm password, "I am not a robot" checkbox.
  - Agar email diya → email OTP.
  - Agar phone diya (jaise `+919876543210`) → SMS OTP (Twilio setup ke baad).
- **OTP screen**: 6-digit code verify karta hai, "Resend" bhi hai.
- **Home screen**: profile pic + naam dikhata hai, Logout button hai. Yahi se aage chat/groups/status wagairah banaye ja sakte hain.

---

## 5. Aage kya add karna hai (next steps, jab bologe)

- Chat list, individual chat screen, real-time messaging (Supabase Realtime se free me ho sakta hai)
- Groups, Status/Stories, Calls tabs (jaise mockup me dikhaya tha)
- Contacts sync
