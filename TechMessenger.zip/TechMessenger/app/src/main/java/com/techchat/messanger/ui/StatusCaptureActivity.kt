package com.techchat.messanger.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.techchat.messanger.data.ChatRepository
import com.techchat.messanger.databinding.ActivityStatusCaptureBinding
import kotlinx.coroutines.launch

class StatusCaptureActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStatusCaptureBinding
    private val repository = ChatRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStatusCaptureBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnClose.setOnClickListener { finish() }
        binding.btnPostStatus.setOnClickListener { post() }
    }

    private fun post() {
        val text = binding.edtStatus.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) {
            Toast.makeText(this, "Write something first", Toast.LENGTH_SHORT).show()
            return
        }
        val uid = repository.currentUserId() ?: return
        lifecycleScope.launch {
            try {
                repository.postStatus(uid, text)
                Toast.makeText(this@StatusCaptureActivity, "Status posted", Toast.LENGTH_SHORT).show()
                finish()
            } catch (e: Exception) {
                Toast.makeText(this@StatusCaptureActivity, "Could not post status. Try again.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
