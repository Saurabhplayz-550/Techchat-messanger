package com.techchat.messanger.ui

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class HomePagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {

    private val factories = listOf<() -> Fragment>(
        { ChatsFragment() },
        { GroupsFragment() },
        { StatusFragment() },
        { CallsFragment() }
    )

    // Keep direct references to created fragments so the host activity can
    // reach them (e.g. for live search) without depending on FragmentManager's
    // internal tag-naming scheme.
    private val created = arrayOfNulls<Fragment>(factories.size)

    override fun getItemCount(): Int = factories.size

    override fun createFragment(position: Int): Fragment {
        val fragment = factories[position]()
        created[position] = fragment
        return fragment
    }

    fun fragmentAt(position: Int): Fragment? = created.getOrNull(position)
}
