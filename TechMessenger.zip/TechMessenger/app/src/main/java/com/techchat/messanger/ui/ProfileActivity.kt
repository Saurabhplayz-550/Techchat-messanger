package com.techchat.messanger.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import coil.load
import com.techchat.messanger.R
import com.techchat.messanger.data.AuthRepository
import com.techchat.messanger.data.ChatRepository
import com.techchat.messanger.data.Profile
import com.techchat.messanger.databinding.ActivityProfileBinding
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.launch

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding
    private val authRepository = AuthRepository()
    private val repository = ChatRepository()
    private var currentProfile: Profile? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) uploadNewAvatar(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnLogout.setOnClickListener { logout() }
        binding.btnChangeAvatar.setOnClickListener { pickImage.launch("image/*") }
        binding.btnEditProfile.setOnClickListener { openEdit() }

        binding.rowAccount.setOnClickListener { openInfo("account") }
        binding.rowPrivacy.setOnClickListener { openInfo("privacy") }
        binding.rowChats.setOnClickListener { openInfo("chats") }
        binding.rowNotifications.setOnClickListener { openInfo("notifications") }
        binding.rowStorage.setOnClickListener { openInfo("storage") }
        binding.rowHelp.setOnClickListener { openInfo("help") }

        loadProfile()
    }

    override fun onResume() {
        super.onResume()
        loadProfile()
    }

    private fun loadProfile() {
        val uid = repository.currentUserId() ?: return
        lifecycleScope.launch {
            try {
                val profile = repository.getProfile(uid)
                currentProfile = profile
                binding.txtFullName.text = profile?.full_name ?: profile?.username ?: "—"
                binding.txtUsername.text = if (profile != null) "@${profile.username}" else ""
                binding.txtEmail.text = authRepository.currentUserEmail() ?: ""
                if (!profile?.avatar_url.isNullOrBlank()) {
                    binding.imgAvatar.load(profile?.avatar_url) {
                        placeholder(R.drawable.ic_person)
                        error(R.drawable.ic_person)
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun uploadNewAvatar(uri: Uri) {
        val uid = repository.currentUserId() ?: return
        lifecycleScope.launch {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@launch
                val result = authRepository.uploadAvatar(bytes, uid, "jpg")
                if (result is com.techchat.messanger.data.AuthResult.Success) {
                    updateAvatarUrl(uid, result.data)
                } else if (result is com.techchat.messanger.data.AuthResult.Failure) {
                    Toast.makeText(this@ProfileActivity, result.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ProfileActivity, "Could not update photo", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun updateAvatarUrl(uid: String, url: String) {
        try {
            SupabaseProfileUpdater.updateAvatar(uid, url)
            loadProfile()
        } catch (e: Exception) {
            Toast.makeText(this, "Photo uploaded but profile update failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openEdit() {
        val profile = currentProfile ?: return
        val intent = Intent(this, EditProfileActivity::class.java).apply {
            putExtra(EditProfileActivity.EXTRA_FULL_NAME, profile.full_name)
            putExtra(EditProfileActivity.EXTRA_USERNAME, profile.username)
        }
        startActivity(intent)
    }

    private fun openInfo(topic: String) {
        startActivity(Intent(this, InfoActivity::class.java).putExtra(InfoActivity.EXTRA_TOPIC, topic))
    }

    private fun logout() {
        lifecycleScope.launch {
            authRepository.signOut()
            startActivity(Intent(this@ProfileActivity, LoginActivity::class.java))
            finishAffinity()
        }
    }
}

/** Small helper so ProfileActivity/EditProfileActivity share one profiles-table writer. */
object SupabaseProfileUpdater {
    private val postgrest = com.techchat.messanger.data.SupabaseClientProvider.postgrest

    suspend fun updateAvatar(uid: String, url: String) {
        postgrest.from("profiles").update(
            { set("avatar_url", url) }
        ) {
            filter { eq("id", uid) }
        }
    }

    suspend fun updateNameAndUsername(uid: String, fullName: String, username: String) {
        postgrest.from("profiles").update(
            {
                set("full_name", fullName)
                set("username", username)
            }
        ) {
            filter { eq("id", uid) }
        }
    }
}
