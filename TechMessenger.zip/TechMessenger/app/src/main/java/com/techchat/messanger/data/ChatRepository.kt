package com.techchat.messanger.data

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.postgrest.rpc
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.Json

/**
 * Data layer for chats, messages, contacts, calls and status.
 *
 * Note on "live" updates: this polls Postgrest on a short interval rather than
 * using Supabase Realtime channels, so it works reliably without needing a
 * websocket-capable Ktor engine. Messages you send appear instantly
 * (optimistic local add in the UI); messages from the other side show up
 * within a few seconds.
 */
class ChatRepository {

    private val postgrest = SupabaseClientProvider.postgrest
    private val auth = SupabaseClientProvider.auth

    fun currentUserId(): String? = auth.currentUserOrNull()?.id

    suspend fun getProfile(userId: String): Profile? {
        return try {
            postgrest.from("profiles").select {
                filter { eq("id", userId) }
            }.decodeSingleOrNull()
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getChatList(): List<ChatListItem> {
        return postgrest.rpc("get_chat_list").decodeList()
    }

    suspend fun getOrCreateDirectConversation(otherUserId: String): String {
        val response = postgrest.rpc("get_or_create_direct_conversation", ConversationIdArg(otherUserId))
        return Json.parseToJsonElement(response.data).toString().trim('"')
    }

    suspend fun createGroup(name: String, memberIds: List<String>): String {
        val response = postgrest.rpc("create_group_conversation", NewGroupArgs(name, memberIds))
        return Json.parseToJsonElement(response.data).toString().trim('"')
    }

    suspend fun listContacts(): List<Contact> {
        return postgrest.rpc("list_contacts").decodeList()
    }

    suspend fun markConversationRead(conversationId: String) {
        postgrest.rpc("mark_conversation_read", ConvReadArg(conversationId))
    }

    suspend fun getMessages(conversationId: String): List<Message> {
        return postgrest.from("messages").select {
            filter { eq("conversation_id", conversationId) }
            order("created_at", Order.ASCENDING)
        }.decodeList()
    }

    suspend fun sendMessage(conversationId: String, senderId: String, content: String) {
        postgrest.from("messages").insert(NewMessage(conversationId, senderId, content))
    }

    /**
     * Emits the full message list for a conversation immediately, then again
     * every [intervalMs] while collected, so a chat screen stays "live"
     * without a manual pull-to-refresh.
     */
    fun pollMessages(conversationId: String, intervalMs: Long = 3000): Flow<List<Message>> = flow {
        while (true) {
            try {
                emit(getMessages(conversationId))
            } catch (_: Exception) {
                // transient network error - keep the loop alive, try again next tick
            }
            delay(intervalMs)
        }
    }

    fun pollChatList(intervalMs: Long = 5000): Flow<List<ChatListItem>> = flow {
        while (true) {
            try {
                emit(getChatList())
            } catch (_: Exception) {
            }
            delay(intervalMs)
        }
    }

    suspend fun getOtherParticipant(conversationId: String, myId: String): String? {
        return try {
            val rows: List<ParticipantRow> = postgrest.from("conversation_participants").select {
                filter { eq("conversation_id", conversationId) }
            }.decodeList()
            rows.map { it.user_id }.firstOrNull { it != myId }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getCallLog(): List<CallLogItem> {
        return postgrest.rpc("get_call_log").decodeList()
    }

    suspend fun logCall(callerId: String, calleeId: String, type: String, status: String, conversationId: String? = null) {
        postgrest.from("calls").insert(NewCall(conversationId, callerId, calleeId, type, status))
    }

    suspend fun getStatusFeed(): List<StatusFeedItem> {
        return postgrest.rpc("get_status_feed").decodeList()
    }

    suspend fun getMyStatuses(userId: String): List<StatusUpdate> {
        return postgrest.from("status_updates").select {
            filter { eq("user_id", userId) }
            order("created_at", Order.DESCENDING)
        }.decodeList()
    }

    suspend fun getStatusesFor(userId: String): List<StatusUpdate> {
        return postgrest.from("status_updates").select {
            filter { eq("user_id", userId) }
            order("created_at", Order.ASCENDING)
        }.decodeList()
    }

    suspend fun postStatus(userId: String, content: String) {
        postgrest.from("status_updates").insert(NewStatusInsert(userId, content))
    }

    suspend fun markStatusViewed(statusId: String, viewerId: String) {
        try {
            postgrest.from("status_views").insert(NewStatusView(statusId, viewerId))
        } catch (_: Exception) {
            // already viewed (unique key conflict) - ignore
        }
    }
}
