package com.techchat.messanger.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import coil.load
import com.techchat.messanger.R
import com.techchat.messanger.data.ChatRepository
import com.techchat.messanger.data.StatusUpdate
import com.techchat.messanger.databinding.ActivityStatusViewerBinding
import com.techchat.messanger.util.TimeFormat
import kotlinx.coroutines.launch

class StatusViewerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStatusViewerBinding
    private val repository = ChatRepository()
    private val handler = Handler(Looper.getMainLooper())
    private var statuses: List<StatusUpdate> = emptyList()
    private var index = 0
    private val displayMs = 5000L

    private val advanceRunnable = Runnable { showNext() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStatusViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val userId = intent.getStringExtra(EXTRA_USER_ID) ?: run { finish(); return }
        val name = intent.getStringExtra(EXTRA_NAME) ?: ""
        val avatar = intent.getStringExtra(EXTRA_AVATAR)

        binding.txtName.text = name
        if (!avatar.isNullOrBlank()) {
            binding.imgAvatar.load(avatar) { placeholder(R.drawable.ic_person); error(R.drawable.ic_person) }
        }
        binding.btnClose.setOnClickListener { finish() }
        binding.tapNext.setOnClickListener { showNext() }
        binding.tapPrev.setOnClickListener { showPrev() }

        lifecycleScope.launch {
            statuses = repository.getStatusesFor(userId)
            if (statuses.isEmpty()) {
                finish()
            } else {
                showAt(0)
            }
        }
    }

    private fun showAt(i: Int) {
        handler.removeCallbacks(advanceRunnable)
        if (i < 0) { finish(); return }
        if (i >= statuses.size) { finish(); return }
        index = i
        val status = statuses[index]
        binding.txtContent.text = status.content ?: ""
        binding.txtTime.text = TimeFormat.shortTime(status.created_at)

        val viewerId = repository.currentUserId()
        if (viewerId != null && status.id != null) {
            lifecycleScope.launch {
                try {
                    repository.markStatusViewed(status.id, viewerId)
                } catch (_: Exception) {
                }
            }
        }
        handler.postDelayed(advanceRunnable, displayMs)
    }

    private fun showNext() = showAt(index + 1)
    private fun showPrev() = showAt(index - 1)

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        const val EXTRA_USER_ID = "user_id"
        const val EXTRA_NAME = "name"
        const val EXTRA_AVATAR = "avatar"
    }
}
