package com.techchat.messanger.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.techchat.messanger.data.AuthRepository
import com.techchat.messanger.data.AuthResult
import com.techchat.messanger.data.PendingAvatar
import com.techchat.messanger.data.SupabaseClientProvider
import com.techchat.messanger.databinding.ActivityOtpBinding
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

class OtpActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_IDENTIFIER = "extra_identifier"
    }

    private lateinit var binding: ActivityOtpBinding
    private val authRepository = AuthRepository()
    private lateinit var identifier: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOtpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        identifier = intent.getStringExtra(EXTRA_IDENTIFIER).orEmpty()
        binding.txtTitle.text = "Verify your email"
        binding.txtSubtitle.text = "Enter the 6-digit code we sent to your email: $identifier"

        binding.btnVerify.setOnClickListener { attemptVerify() }
        binding.txtResend.setOnClickListener { resendCode() }
    }

    private fun attemptVerify() {
        val code = binding.edtOtp.text?.toString()?.trim().orEmpty()
        if (code.length != 6) {
            showError("Enter the 6-digit code")
            return
        }

        setLoading(true)
        lifecycleScope.launch {
            when (val result = authRepository.verifySignupOtp(identifier, code)) {
                is AuthResult.Success -> {
                    uploadAvatarIfNeeded()
                    setLoading(false)
                    startActivity(Intent(this@OtpActivity, HomeActivity::class.java))
                    finish()
                }
                is AuthResult.Failure -> {
                    setLoading(false)
                    showError(result.message)
                }
            }
        }
    }

    private suspend fun uploadAvatarIfNeeded() {
        val bytes = PendingAvatar.bytes ?: return
        val userId = SupabaseClientProvider.auth.currentUserOrNull()?.id ?: return
        val uploadResult = authRepository.uploadAvatar(bytes, userId, PendingAvatar.extension)
        if (uploadResult is AuthResult.Success) {
            try {
                SupabaseClientProvider.postgrest.from("profiles").update(
                    buildJsonObject { put("avatar_url", uploadResult.data) }
                ) {
                    filter { eq("id", userId) }
                }
            } catch (e: Exception) {
                // Non-fatal: profile row still exists without an avatar.
            }
        }
        PendingAvatar.clear()
    }

    private fun resendCode() {
        setLoading(true)
        lifecycleScope.launch {
            val result = authRepository.resendSignupOtp(identifier)
            setLoading(false)
            if (result is AuthResult.Failure) {
                showError(result.message)
            } else {
                binding.txtError.setTextColor(getColor(com.techchat.messanger.R.color.brand_blue))
                binding.txtError.text = "A new code has been sent"
                binding.txtError.visibility = View.VISIBLE
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progress.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnVerify.isEnabled = !loading
    }

    private fun showError(message: String) {
        binding.txtError.setTextColor(getColor(com.techchat.messanger.R.color.error_red))
        binding.txtError.text = message
        binding.txtError.visibility = View.VISIBLE
    }
}
