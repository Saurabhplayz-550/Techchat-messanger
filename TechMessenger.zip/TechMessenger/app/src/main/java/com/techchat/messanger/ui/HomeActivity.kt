package com.techchat.messanger.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.tabs.TabLayoutMediator
import coil.load
import com.techchat.messanger.R
import com.techchat.messanger.data.AuthRepository
import com.techchat.messanger.data.ChatRepository
import com.techchat.messanger.databinding.ActivityHomeBinding
import kotlinx.coroutines.launch

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private val authRepository = AuthRepository()
    private val chatRepository = ChatRepository()
    private val tabTitles = listOf("Chats", "Groups", "Status", "Calls")
    private var searchOpen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!authRepository.isLoggedIn()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        val pagerAdapter = HomePagerAdapter(this)
        binding.viewPager.adapter = pagerAdapter
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = tabTitles[position]
        }.attach()

        binding.fabAction.setOnClickListener { onFabClicked() }
        binding.viewPager.registerOnPageChangeCallback(object : androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                binding.fabAction.setImageResource(if (position == 1) R.drawable.ic_group else R.drawable.ic_edit)
            }
        })

        binding.imgMyAvatar.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        binding.btnSearch.setOnClickListener { toggleSearch() }
        binding.edtSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterCurrentTab(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.btnMore.setOnClickListener { showMoreMenu(it) }

        loadMyAvatar()
    }

    override fun onResume() {
        super.onResume()
        loadMyAvatar()
    }

    private fun loadMyAvatar() {
        val uid = chatRepository.currentUserId() ?: return
        lifecycleScope.launch {
            try {
                val profile = chatRepository.getProfile(uid)
                val url = profile?.avatar_url
                if (!url.isNullOrBlank()) {
                    binding.imgMyAvatar.load(url) {
                        placeholder(R.drawable.ic_person)
                        error(R.drawable.ic_person)
                    }
                }
            } catch (e: Exception) {
            }
        }
    }

    private fun onFabClicked() {
        val isGroupsTab = binding.viewPager.currentItem == 1
        val isStatusTab = binding.viewPager.currentItem == 2
        when {
            isGroupsTab -> {
                startActivity(Intent(this, NewChatActivity::class.java).putExtra(NewChatActivity.EXTRA_MODE, NewChatActivity.MODE_GROUP))
            }
            isStatusTab -> {
                startActivity(Intent(this, StatusCaptureActivity::class.java))
            }
            else -> {
                startActivity(Intent(this, NewChatActivity::class.java).putExtra(NewChatActivity.EXTRA_MODE, NewChatActivity.MODE_CHAT))
            }
        }
    }

    private fun toggleSearch() {
        searchOpen = !searchOpen
        if (searchOpen) {
            binding.txtHomeTitle.visibility = View.GONE
            binding.edtSearch.visibility = View.VISIBLE
            binding.edtSearch.requestFocus()
        } else {
            binding.txtHomeTitle.visibility = View.VISIBLE
            binding.edtSearch.visibility = View.GONE
            binding.edtSearch.setText("")
            filterCurrentTab("")
        }
    }

    private fun filterCurrentTab(query: String) {
        val adapter = binding.viewPager.adapter as? HomePagerAdapter ?: return
        val fragment = adapter.fragmentAt(binding.viewPager.currentItem)
        if (fragment is BaseChatListFragment) fragment.filter(query)
    }

    private fun showMoreMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.menu_home_more, popup.menu)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menu_new_group -> {
                    startActivity(Intent(this, NewChatActivity::class.java).putExtra(NewChatActivity.EXTRA_MODE, NewChatActivity.MODE_GROUP))
                    true
                }
                R.id.menu_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                R.id.menu_logout -> {
                    lifecycleScope.launch {
                        authRepository.signOut()
                        startActivity(Intent(this@HomeActivity, LoginActivity::class.java))
                        finish()
                    }
                    true
                }
                else -> false
            }
        }
        popup.show()
    }
}
