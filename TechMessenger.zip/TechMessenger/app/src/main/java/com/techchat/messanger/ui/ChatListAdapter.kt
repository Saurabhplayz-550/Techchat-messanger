package com.techchat.messanger.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.techchat.messanger.R
import com.techchat.messanger.data.ChatListItem
import com.techchat.messanger.util.TimeFormat

class ChatListAdapter(
    private val onClick: (ChatListItem) -> Unit
) : RecyclerView.Adapter<ChatListAdapter.VH>() {

    private val items = mutableListOf<ChatListItem>()
    private var filtered = mutableListOf<ChatListItem>()

    fun submit(newItems: List<ChatListItem>) {
        items.clear()
        items.addAll(newItems)
        filtered = items.toMutableList()
        notifyDataSetChanged()
    }

    fun filter(query: String) {
        filtered = if (query.isBlank()) {
            items.toMutableList()
        } else {
            items.filter { it.display_name.contains(query, ignoreCase = true) }.toMutableList()
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_chat, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(filtered[position])
    }

    override fun getItemCount(): Int = filtered.size

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imgAvatar: ImageView = itemView.findViewById(R.id.imgAvatar)
        private val txtName: TextView = itemView.findViewById(R.id.txtName)
        private val txtLastMessage: TextView = itemView.findViewById(R.id.txtLastMessage)
        private val txtTime: TextView = itemView.findViewById(R.id.txtTime)
        private val txtUnread: TextView = itemView.findViewById(R.id.txtUnread)

        fun bind(item: ChatListItem) {
            txtName.text = item.display_name
            txtLastMessage.text = item.last_message_preview ?: "Say hi 👋"
            txtTime.text = TimeFormat.shortTime(item.last_message_at)
            if (item.unread_count > 0) {
                txtUnread.visibility = View.VISIBLE
                txtUnread.text = if (item.unread_count > 99) "99+" else item.unread_count.toString()
            } else {
                txtUnread.visibility = View.GONE
            }
            if (!item.display_avatar.isNullOrBlank()) {
                imgAvatar.load(item.display_avatar) {
                    placeholder(R.drawable.ic_person)
                    error(R.drawable.ic_person)
                }
            } else {
                imgAvatar.setImageResource(if (item.is_group) R.drawable.ic_group else R.drawable.ic_person)
            }
            itemView.setOnClickListener { onClick(item) }
        }
    }
}
