package com.techchat.messanger.data

import io.github.jan.supabase.auth.OtpType
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.postgrest.rpc
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.jsonPrimitive
import java.util.UUID

sealed class AuthResult<out T> {
    data class Success<T>(val data: T) : AuthResult<T>()
    data class Failure(val message: String) : AuthResult<Nothing>()
}

class AuthRepository {

    private val auth = SupabaseClientProvider.auth
    private val postgrest = SupabaseClientProvider.postgrest
    private val storage = SupabaseClientProvider.storage

    fun isValidIdentifier(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    /**
     * Step 1 of sign up: creates the auth user (unconfirmed) and sends a 6-digit
     * OTP code by email.
     */
    suspend fun signUp(
        email: String,
        password: String,
        username: String,
        fullName: String,
        avatarUrl: String?
    ): AuthResult<Unit> {
        return try {
            val meta = buildJsonObject {
                put("username", JsonPrimitive(username))
                put("full_name", JsonPrimitive(fullName))
                avatarUrl?.let { put("avatar_url", JsonPrimitive(it)) }
            }
            auth.signUpWith(Email) {
                this.email = email
                this.password = password
                data = meta
            }
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            AuthResult.Failure(friendlyError(e))
        }
    }

    /** Verifies the 6-digit code sent to the user's email after signup. */
    suspend fun verifySignupOtp(email: String, code: String): AuthResult<Unit> {
        return try {
            auth.verifyEmailOtp(type = OtpType.Email.SIGNUP, email = email, token = code)
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            AuthResult.Failure(friendlyError(e))
        }
    }

    /** Resends the signup OTP code by email. */
    suspend fun resendSignupOtp(email: String): AuthResult<Unit> {
        return try {
            auth.resendEmail(OtpType.Email.SIGNUP, email)
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            AuthResult.Failure(friendlyError(e))
        }
    }

    /**
     * Login accepts email or username.
     * - "@" in the input -> straight email login.
     * - Otherwise treated as a username -> resolved via get_login_email() RPC
     *   to find the real email tied to that account.
     */
    suspend fun login(identifier: String, password: String): AuthResult<Unit> {
        return try {
            val trimmed = identifier.trim()
            val email = if (trimmed.contains("@")) {
                trimmed
            } else {
                resolveEmail(trimmed) ?: return AuthResult.Failure("Account not found")
            }
            auth.signInWith(Email) {
                this.email = email
                this.password = password
            }
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            AuthResult.Failure(friendlyError(e))
        }
    }

    private suspend fun resolveEmail(username: String): String? {
        return try {
            val response = postgrest.rpc("get_login_email", LoginIdentifierArgs(username))
            val json = Json { ignoreUnknownKeys = true }
            val element = json.parseToJsonElement(response.data)
            if (element is JsonNull) null else element.jsonPrimitive.content.ifBlank { null }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun uploadAvatar(localBytes: ByteArray, userId: String, ext: String): AuthResult<String> {
        return try {
            val fileName = "$userId/${UUID.randomUUID()}.$ext"
            storage.from("avatars").upload(fileName, localBytes)
            val url = storage.from("avatars").publicUrl(fileName)
            AuthResult.Success(url)
        } catch (e: Exception) {
            AuthResult.Failure(friendlyError(e))
        }
    }

    fun currentUserEmail(): String? = auth.currentUserOrNull()?.email

    fun isLoggedIn(): Boolean = auth.currentUserOrNull() != null

    suspend fun signOut() {
        auth.signOut()
    }

    private fun friendlyError(e: Exception): String {
        return e.message ?: "Something went wrong. Check your internet connection."
    }
}
