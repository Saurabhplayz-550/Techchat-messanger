package com.techchat.messanger.data

import kotlinx.serialization.Serializable

@Serializable
data class Profile(
    val id: String,
    val username: String,
    val full_name: String? = null,
    val email: String,
    val avatar_url: String? = null
)

@Serializable
data class LoginIdentifierArgs(val identifier: String)
