package com.techchat.messanger.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * Small helper to turn a Postgres timestamptz string (e.g.
 * "2026-09-18T10:23:45.123456+00:00") into UI-friendly relative labels,
 * without needing java.time (keeps minSdk 24 happy, no desugaring required).
 */
object TimeFormat {

    private fun parseUtcMillis(iso: String): Long? {
        return try {
            val datePart = iso.substring(0, 10)
            val timePart = iso.substring(11, 19)
            val year = datePart.substring(0, 4).toInt()
            val month = datePart.substring(5, 7).toInt() - 1
            val day = datePart.substring(8, 10).toInt()
            val hour = timePart.substring(0, 2).toInt()
            val min = timePart.substring(3, 5).toInt()
            val sec = timePart.substring(6, 8).toInt()
            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
            cal.set(year, month, day, hour, min, sec)
            cal.set(Calendar.MILLISECOND, 0)
            cal.timeInMillis
        } catch (e: Exception) {
            null
        }
    }

    /** "9:24 AM" for today, "Mon" within the last week, else "12 Sep". */
    fun shortTime(iso: String?): String {
        if (iso.isNullOrBlank()) return ""
        val millis = parseUtcMillis(iso) ?: return ""
        val now = Calendar.getInstance()
        val then = Calendar.getInstance().apply { timeInMillis = millis }

        val sameDay = now.get(Calendar.YEAR) == then.get(Calendar.YEAR) &&
            now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)
        if (sameDay) {
            return SimpleDateFormat("h:mm a", Locale.getDefault()).format(then.time)
        }

        val diffDays = (now.timeInMillis - then.timeInMillis) / (1000 * 60 * 60 * 24)
        if (diffDays in 1..6) {
            return SimpleDateFormat("EEE", Locale.getDefault()).format(then.time)
        }
        return SimpleDateFormat("d MMM", Locale.getDefault()).format(then.time)
    }

    /** "Yesterday, 8:45 AM" style label used in the call log. */
    fun callTimeLabel(iso: String?): String {
        if (iso.isNullOrBlank()) return ""
        val millis = parseUtcMillis(iso) ?: return ""
        val now = Calendar.getInstance()
        val then = Calendar.getInstance().apply { timeInMillis = millis }
        val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(then.time)

        val sameDay = now.get(Calendar.YEAR) == then.get(Calendar.YEAR) &&
            now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)
        if (sameDay) return "Today, $time"

        val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val wasYesterday = yesterday.get(Calendar.YEAR) == then.get(Calendar.YEAR) &&
            yesterday.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)
        if (wasYesterday) return "Yesterday, $time"

        val datePart = SimpleDateFormat("d MMM", Locale.getDefault()).format(then.time)
        return "$datePart, $time"
    }

    /** "12:34" running call-duration style label from a start time in millis. */
    fun elapsed(startMillis: Long): String {
        val secs = ((System.currentTimeMillis() - startMillis) / 1000).coerceAtLeast(0)
        val m = secs / 60
        val s = secs % 60
        return String.format(Locale.getDefault(), "%02d:%02d", m, s)
    }
}
