package com.techchat.messanger.data

import kotlinx.serialization.Serializable

@Serializable
data class ChatListItem(
    val conversation_id: String,
    val is_group: Boolean,
    val display_name: String,
    val display_avatar: String? = null,
    val last_message_preview: String? = null,
    val last_message_at: String? = null,
    val unread_count: Long = 0
)

@Serializable
data class Message(
    val id: String? = null,
    val conversation_id: String,
    val sender_id: String,
    val content: String,
    val created_at: String? = null
)

@Serializable
data class NewMessage(
    val conversation_id: String,
    val sender_id: String,
    val content: String
)

@Serializable
data class Contact(
    val id: String,
    val username: String,
    val full_name: String? = null,
    val avatar_url: String? = null
)

@Serializable
data class CallLogItem(
    val call_id: String,
    val other_user_id: String,
    val other_name: String,
    val other_avatar: String? = null,
    val call_type: String,
    val direction: String,
    val status: String,
    val created_at: String
)

@Serializable
data class StatusFeedItem(
    val user_id: String,
    val display_name: String,
    val avatar_url: String? = null,
    val status_count: Long = 0,
    val latest_at: String? = null,
    val all_viewed: Boolean = false
)

@Serializable
data class StatusUpdate(
    val id: String? = null,
    val user_id: String,
    val content: String? = null,
    val image_url: String? = null,
    val created_at: String? = null
)

@Serializable
data class NewStatusArgs(val user_id: String, val content: String?)

@Serializable
data class ConversationIdArg(val other_user_id: String)

@Serializable
data class ConvReadArg(val conv_id: String)

@Serializable
data class NewGroupArgs(val group_name: String, val member_ids: List<String>)

@Serializable
data class NewCall(
    val conversation_id: String? = null,
    val caller_id: String,
    val callee_id: String,
    val call_type: String,
    val status: String
)

@Serializable
data class ParticipantRow(val user_id: String)

@Serializable
data class NewStatusInsert(val user_id: String, val content: String)

@Serializable
data class NewStatusView(val status_id: String, val viewer_id: String)
