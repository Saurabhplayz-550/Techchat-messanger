package com.techchat.messanger.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.techchat.messanger.R
import com.techchat.messanger.data.StatusFeedItem

/**
 * First row is always "My status" (add / view own). Remaining rows are
 * other users' active statuses from get_status_feed().
 */
class StatusAdapter(
    private val myAvatarUrl: () -> String?,
    private val onMyStatusClick: () -> Unit,
    private val onOtherClick: (StatusFeedItem) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val others = mutableListOf<StatusFeedItem>()

    fun submit(items: List<StatusFeedItem>) {
        others.clear(); others.addAll(items)
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int) = if (position == 0) 0 else 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_status_row, parent, false)
        return if (viewType == 0) MyVH(v) else OtherVH(v)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is MyVH) holder.bind()
        else if (holder is OtherVH) holder.bind(others[position - 1])
    }

    override fun getItemCount() = others.size + 1

    inner class MyVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imgAvatar: ImageView = itemView.findViewById(R.id.imgAvatar)
        private val ring: View = itemView.findViewById(R.id.ringUnseen)
        private val badge: ImageView = itemView.findViewById(R.id.imgAddBadge)
        private val txtName: TextView = itemView.findViewById(R.id.txtName)
        private val txtSubtitle: TextView = itemView.findViewById(R.id.txtSubtitle)

        fun bind() {
            txtName.text = "My Status"
            txtSubtitle.text = "Tap to add a status update"
            ring.visibility = View.GONE
            badge.visibility = View.VISIBLE
            val url = myAvatarUrl()
            if (!url.isNullOrBlank()) {
                imgAvatar.load(url) { placeholder(R.drawable.ic_person); error(R.drawable.ic_person) }
            } else {
                imgAvatar.setImageResource(R.drawable.ic_person)
            }
            itemView.setOnClickListener { onMyStatusClick() }
        }
    }

    inner class OtherVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imgAvatar: ImageView = itemView.findViewById(R.id.imgAvatar)
        private val ring: View = itemView.findViewById(R.id.ringUnseen)
        private val badge: ImageView = itemView.findViewById(R.id.imgAddBadge)
        private val txtName: TextView = itemView.findViewById(R.id.txtName)
        private val txtSubtitle: TextView = itemView.findViewById(R.id.txtSubtitle)

        fun bind(item: StatusFeedItem) {
            txtName.text = item.display_name
            txtSubtitle.text = if (item.status_count > 1) "${item.status_count} updates" else "Tap to view"
            badge.visibility = View.GONE
            ring.visibility = View.VISIBLE
            ring.setBackgroundResource(
                if (item.all_viewed) R.drawable.bg_status_ring_seen else R.drawable.bg_status_ring_unseen
            )
            if (!item.avatar_url.isNullOrBlank()) {
                imgAvatar.load(item.avatar_url) { placeholder(R.drawable.ic_person); error(R.drawable.ic_person) }
            } else {
                imgAvatar.setImageResource(R.drawable.ic_person)
            }
            itemView.setOnClickListener { onOtherClick(item) }
        }
    }
}
