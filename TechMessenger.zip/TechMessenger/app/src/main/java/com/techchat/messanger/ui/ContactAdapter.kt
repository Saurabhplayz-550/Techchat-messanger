package com.techchat.messanger.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.techchat.messanger.R
import com.techchat.messanger.data.Contact

class ContactAdapter(
    private val multiSelect: Boolean,
    private val onClick: (Contact) -> Unit,
    private val onSelectionChanged: (List<Contact>) -> Unit = {}
) : RecyclerView.Adapter<ContactAdapter.VH>() {

    private val all = mutableListOf<Contact>()
    private var filtered = mutableListOf<Contact>()
    private val selected = linkedSetOf<String>()

    fun submit(items: List<Contact>) {
        all.clear(); all.addAll(items)
        filtered = all.toMutableList()
        notifyDataSetChanged()
    }

    fun filter(query: String) {
        filtered = if (query.isBlank()) all.toMutableList()
        else all.filter {
            it.username.contains(query, true) || (it.full_name?.contains(query, true) == true)
        }.toMutableList()
        notifyDataSetChanged()
    }

    fun selectedContacts(): List<Contact> = all.filter { selected.contains(it.id) }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_contact, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(filtered[position])
    override fun getItemCount() = filtered.size

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imgAvatar: ImageView = itemView.findViewById(R.id.imgAvatar)
        private val txtName: TextView = itemView.findViewById(R.id.txtName)
        private val txtUsername: TextView = itemView.findViewById(R.id.txtUsername)
        private val chk: CheckBox = itemView.findViewById(R.id.chkSelected)

        fun bind(c: Contact) {
            txtName.text = c.full_name ?: c.username
            txtUsername.text = "@${c.username}"
            if (!c.avatar_url.isNullOrBlank()) {
                imgAvatar.load(c.avatar_url) { placeholder(R.drawable.ic_person); error(R.drawable.ic_person) }
            } else {
                imgAvatar.setImageResource(R.drawable.ic_person)
            }
            chk.visibility = if (multiSelect) View.VISIBLE else View.GONE
            chk.setOnCheckedChangeListener(null)
            chk.isChecked = selected.contains(c.id)
            chk.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) selected.add(c.id) else selected.remove(c.id)
                onSelectionChanged(selectedContacts())
            }
            itemView.setOnClickListener {
                if (multiSelect) {
                    chk.isChecked = !chk.isChecked
                } else {
                    onClick(c)
                }
            }
        }
    }
}
