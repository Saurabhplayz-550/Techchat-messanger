package com.techchat.messanger.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.MimeTypeMap
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import coil.load
import com.techchat.messanger.data.AuthRepository
import com.techchat.messanger.data.AuthResult
import com.techchat.messanger.data.PendingAvatar
import com.techchat.messanger.databinding.ActivitySignupBinding
import com.techchat.messanger.util.UsernameRules
import kotlinx.coroutines.launch
import java.util.Locale

class SignupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding
    private val authRepository = AuthRepository()
    private var pickedAvatarUri: Uri? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            pickedAvatarUri = uri
            binding.imgAvatar.load(uri) {
                crossfade(true)
            }
            readAvatarBytes(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        UsernameRules.applyTo(binding.edtUsername)
        binding.btnBack.setOnClickListener { finish() }
        binding.frameAvatar.setOnClickListener { pickImage.launch("image/*") }
        binding.btnSubmit.setOnClickListener { attemptSignup() }
    }

    private fun readAvatarBytes(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            val type = contentResolver.getType(uri)
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(type) ?: "jpg"
            PendingAvatar.bytes = bytes
            PendingAvatar.extension = ext.lowercase(Locale.ROOT)
        } catch (e: Exception) {
            // Avatar is optional; ignore failures and continue without it.
            PendingAvatar.clear()
        }
    }

    private fun attemptSignup() {
        val username = binding.edtUsername.text?.toString()?.trim().orEmpty()
        val fullName = binding.edtFullName.text?.toString()?.trim().orEmpty()
        val email = binding.edtIdentifier.text?.toString()?.trim().orEmpty()
        val password = binding.edtPassword.text?.toString().orEmpty()
        val confirmPassword = binding.edtConfirmPassword.text?.toString().orEmpty()

        if (username.isEmpty() || fullName.isEmpty() || email.isEmpty() || password.isEmpty()) {
            showError("Please fill in all required fields")
            return
        }
        if (UsernameRules.hasWhitespace(username)) {
            showError("Username can't contain spaces")
            return
        }
        if (!authRepository.isValidIdentifier(email)) {
            showError("Enter a valid email address")
            return
        }
        if (password.length < 6) {
            showError("Password must be at least 6 characters")
            return
        }
        if (password != confirmPassword) {
            showError("Passwords do not match")
            return
        }
        if (!binding.chkNotRobot.isChecked) {
            showError("Please confirm you're not a robot")
            return
        }

        setLoading(true)
        lifecycleScope.launch {
            val result = authRepository.signUp(
                email = email,
                password = password,
                username = username,
                fullName = fullName,
                avatarUrl = null // uploaded after OTP verification, once authenticated
            )
            setLoading(false)
            when (result) {
                is AuthResult.Success -> {
                    val intent = Intent(this@SignupActivity, OtpActivity::class.java).apply {
                        putExtra(OtpActivity.EXTRA_IDENTIFIER, email)
                    }
                    startActivity(intent)
                    finish()
                }
                is AuthResult.Failure -> showError(result.message)
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progress.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnSubmit.isEnabled = !loading
    }

    private fun showError(message: String) {
        binding.txtError.text = message
        binding.txtError.visibility = View.VISIBLE
    }
}
