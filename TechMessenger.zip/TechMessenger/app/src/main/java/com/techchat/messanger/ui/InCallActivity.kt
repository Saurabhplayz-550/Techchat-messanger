package com.techchat.messanger.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import coil.load
import com.techchat.messanger.R
import com.techchat.messanger.data.ChatRepository
import com.techchat.messanger.databinding.ActivityInCallBinding
import kotlinx.coroutines.launch

class InCallActivity : AppCompatActivity() {

    private lateinit var binding: ActivityInCallBinding
    private val repository = ChatRepository()
    private val handler = Handler(Looper.getMainLooper())
    private var connected = false
    private var micOn = true
    private var speakerOn = false
    private var startMillis = 0L

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (connected) {
                binding.txtTimer.text = com.techchat.messanger.util.TimeFormat.elapsed(startMillis)
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInCallBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val otherUserId = intent.getStringExtra(EXTRA_OTHER_USER_ID)
        val name = intent.getStringExtra(EXTRA_NAME) ?: "Unknown"
        val avatar = intent.getStringExtra(EXTRA_AVATAR)
        val type = intent.getStringExtra(EXTRA_TYPE) ?: "audio"
        val conversationId = intent.getStringExtra(EXTRA_CONVERSATION_ID)
        val myId = repository.currentUserId()

        binding.txtName.text = name
        if (!avatar.isNullOrBlank()) {
            binding.imgAvatar.load(avatar) { placeholder(R.drawable.ic_person); error(R.drawable.ic_person) }
        }
        binding.txtCallStatus.text = if (type == "video") "Video calling..." else "Calling..."

        if (myId != null && otherUserId != null) {
            lifecycleScope.launch {
                try {
                    repository.logCall(myId, otherUserId, type, "outgoing", conversationId)
                } catch (_: Exception) {
                }
            }
        }

        // No real signaling/telephony backend is wired up - this simulates the
        // call connecting so every button on screen is fully interactive.
        handler.postDelayed({
            connected = true
            startMillis = System.currentTimeMillis()
            binding.txtCallStatus.text = "Connected"
            handler.post(tickRunnable)
        }, 1800)

        binding.btnMic.setOnClickListener {
            micOn = !micOn
            binding.btnMic.setImageResource(if (micOn) R.drawable.ic_mic else R.drawable.ic_mic_off)
        }
        binding.btnSpeaker.setOnClickListener {
            speakerOn = !speakerOn
            binding.btnSpeaker.alpha = if (speakerOn) 1f else 0.6f
        }
        binding.btnEndCall.setOnClickListener { finish() }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        const val EXTRA_OTHER_USER_ID = "other_user_id"
        const val EXTRA_NAME = "name"
        const val EXTRA_AVATAR = "avatar"
        const val EXTRA_TYPE = "type"
        const val EXTRA_CONVERSATION_ID = "conversation_id"
    }
}
