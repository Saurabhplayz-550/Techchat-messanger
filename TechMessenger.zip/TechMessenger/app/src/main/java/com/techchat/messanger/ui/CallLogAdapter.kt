package com.techchat.messanger.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.techchat.messanger.R
import com.techchat.messanger.data.CallLogItem
import com.techchat.messanger.util.TimeFormat

class CallLogAdapter(
    private val onRowClick: (CallLogItem) -> Unit,
    private val onCallBack: (CallLogItem) -> Unit
) : RecyclerView.Adapter<CallLogAdapter.VH>() {

    private val items = mutableListOf<CallLogItem>()

    fun submit(newItems: List<CallLogItem>) {
        items.clear(); items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_call_row, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])
    override fun getItemCount() = items.size

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imgAvatar: ImageView = itemView.findViewById(R.id.imgAvatar)
        private val txtName: TextView = itemView.findViewById(R.id.txtName)
        private val imgDirection: ImageView = itemView.findViewById(R.id.imgDirection)
        private val txtTime: TextView = itemView.findViewById(R.id.txtTime)
        private val btnCallBack: ImageView = itemView.findViewById(R.id.btnCallBack)

        fun bind(item: CallLogItem) {
            txtName.text = item.other_name
            txtTime.text = TimeFormat.callTimeLabel(item.created_at)
            val isMissed = item.status == "missed" && item.direction == "incoming"
            val color = if (isMissed) 0xFFE53935.toInt() else 0xFF2E7D32.toInt()
            imgDirection.setColorFilter(color)
            txtTime.setTextColor(if (isMissed) 0xFFE53935.toInt() else itemView.context.getColor(R.color.text_secondary))
            imgDirection.setImageResource(
                if (item.call_type == "video") R.drawable.ic_video_call else R.drawable.ic_call
            )
            btnCallBack.setImageResource(
                if (item.call_type == "video") R.drawable.ic_video_call else R.drawable.ic_call
            )
            if (!item.other_avatar.isNullOrBlank()) {
                imgAvatar.load(item.other_avatar) { placeholder(R.drawable.ic_person); error(R.drawable.ic_person) }
            } else {
                imgAvatar.setImageResource(R.drawable.ic_person)
            }
            itemView.setOnClickListener { onRowClick(item) }
            btnCallBack.setOnClickListener { onCallBack(item) }
        }
    }
}
