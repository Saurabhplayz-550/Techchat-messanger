package com.techchat.messanger.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.techchat.messanger.R
import com.techchat.messanger.data.Message
import com.techchat.messanger.util.TimeFormat

class MessageAdapter(private val currentUserId: String) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val items = mutableListOf<Message>()

    fun submit(newItems: List<Message>) {
        items.clear(); items.addAll(newItems)
        notifyDataSetChanged()
    }

    fun addLocal(message: Message) {
        items.add(message)
        notifyItemInserted(items.size - 1)
    }

    override fun getItemViewType(position: Int): Int {
        return if (items[position].sender_id == currentUserId) TYPE_SENT else TYPE_RECEIVED
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layout = if (viewType == TYPE_SENT) R.layout.item_message_sent else R.layout.item_message_received
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as VH).bind(items[position])
    }

    override fun getItemCount() = items.size

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val txtContent: TextView = itemView.findViewById(R.id.txtContent)
        private val txtTime: TextView = itemView.findViewById(R.id.txtTime)

        fun bind(message: Message) {
            txtContent.text = message.content
            txtTime.text = TimeFormat.shortTime(message.created_at)
        }
    }

    companion object {
        private const val TYPE_SENT = 0
        private const val TYPE_RECEIVED = 1
    }
}
