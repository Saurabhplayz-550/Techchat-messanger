package com.techchat.messanger.data

/**
 * Holds the picked profile picture bytes in memory between the Signup screen
 * (where it's picked) and the OTP screen (where it's uploaded, once the user
 * is authenticated and allowed to write to Storage).
 */
object PendingAvatar {
    var bytes: ByteArray? = null
    var extension: String = "jpg"

    fun clear() {
        bytes = null
        extension = "jpg"
    }
}
