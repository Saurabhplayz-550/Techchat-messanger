package com.techchat.messanger.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.techchat.messanger.data.ChatRepository
import com.techchat.messanger.databinding.ActivityEditProfileBinding
import com.techchat.messanger.util.UsernameRules
import kotlinx.coroutines.launch

class EditProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditProfileBinding
    private val repository = ChatRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.edtFullName.setText(intent.getStringExtra(EXTRA_FULL_NAME).orEmpty())
        binding.edtUsername.setText(intent.getStringExtra(EXTRA_USERNAME).orEmpty())

        UsernameRules.applyTo(binding.edtUsername)
        binding.btnBack.setOnClickListener { finish() }
        binding.btnSave.setOnClickListener { save() }
    }

    private fun save() {
        val fullName = binding.edtFullName.text?.toString()?.trim().orEmpty()
        val username = binding.edtUsername.text?.toString()?.trim().orEmpty()

        if (fullName.isEmpty() || username.isEmpty()) {
            showError("Name and username can't be empty")
            return
        }

        if (UsernameRules.hasWhitespace(username)) {
            showError("Username can't contain spaces")
            return
        }

        val uid = repository.currentUserId() ?: return
        lifecycleScope.launch {
            try {
                SupabaseProfileUpdater.updateNameAndUsername(uid, fullName, username)
                finish()
            } catch (e: Exception) {
                showError(e.message ?: "Could not save. That username may already be taken.")
            }
        }
    }

    private fun showError(message: String) {
        binding.txtError.text = message
        binding.txtError.visibility = View.VISIBLE
    }

    companion object {
        const val EXTRA_FULL_NAME = "full_name"
        const val EXTRA_USERNAME = "username"
    }
}
