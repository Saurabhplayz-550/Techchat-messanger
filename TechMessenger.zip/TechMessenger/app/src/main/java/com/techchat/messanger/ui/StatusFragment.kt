package com.techchat.messanger.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.techchat.messanger.R
import com.techchat.messanger.data.ChatRepository
import com.techchat.messanger.data.StatusFeedItem
import kotlinx.coroutines.launch

class StatusFragment : Fragment() {

    private val repository = ChatRepository()
    private lateinit var adapter: StatusAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private var myAvatarUrl: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_status, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val recycler = view.findViewById<RecyclerView>(R.id.recyclerStatus)
        swipeRefresh = view.findViewById(R.id.swipeRefresh)

        adapter = StatusAdapter(
            myAvatarUrl = { myAvatarUrl },
            onMyStatusClick = {
                startActivity(Intent(requireContext(), StatusCaptureActivity::class.java))
            },
            onOtherClick = { item -> openViewer(item) }
        )
        recycler.layoutManager = LinearLayoutManager(requireContext())
        recycler.adapter = adapter
        swipeRefresh.setOnRefreshListener { load() }
        load()
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val uid = repository.currentUserId()
                if (uid != null) {
                    myAvatarUrl = repository.getProfile(uid)?.avatar_url
                }
                val feed = repository.getStatusFeed()
                adapter.submit(feed)
            } catch (e: Exception) {
            } finally {
                swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun openViewer(item: StatusFeedItem) {
        val intent = Intent(requireContext(), StatusViewerActivity::class.java).apply {
            putExtra(StatusViewerActivity.EXTRA_USER_ID, item.user_id)
            putExtra(StatusViewerActivity.EXTRA_NAME, item.display_name)
            putExtra(StatusViewerActivity.EXTRA_AVATAR, item.avatar_url)
        }
        startActivity(intent)
    }
}
