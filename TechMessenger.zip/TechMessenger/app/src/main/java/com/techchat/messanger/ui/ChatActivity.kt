package com.techchat.messanger.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import coil.load
import com.techchat.messanger.R
import com.techchat.messanger.data.ChatRepository
import com.techchat.messanger.data.Message
import com.techchat.messanger.databinding.ActivityChatBinding
import kotlinx.coroutines.launch

class ChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatBinding
    private val repository = ChatRepository()
    private lateinit var adapter: MessageAdapter

    private lateinit var conversationId: String
    private var otherUserId: String? = null
    private var isGroup: Boolean = false
    private var lastMessageCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        conversationId = intent.getStringExtra(EXTRA_CONVERSATION_ID) ?: run { finish(); return }
        val name = intent.getStringExtra(EXTRA_NAME) ?: "Chat"
        val avatar = intent.getStringExtra(EXTRA_AVATAR)
        isGroup = intent.getBooleanExtra(EXTRA_IS_GROUP, false)

        val uid = repository.currentUserId()
        if (uid == null) { finish(); return }

        binding.txtName.text = name
        if (!avatar.isNullOrBlank()) {
            binding.imgAvatar.load(avatar) { placeholder(R.drawable.ic_person); error(R.drawable.ic_person) }
        } else {
            binding.imgAvatar.setImageResource(if (isGroup) R.drawable.ic_group else R.drawable.ic_person)
        }

        adapter = MessageAdapter(uid)
        binding.recyclerMessages.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        binding.recyclerMessages.adapter = adapter

        binding.btnBack.setOnClickListener { finish() }
        binding.btnSend.setOnClickListener { sendMessage(uid) }

        if (isGroup) {
            binding.btnAudioCall.visibility = android.view.View.GONE
            binding.btnVideoCall.visibility = android.view.View.GONE
        } else {
            binding.btnAudioCall.setOnClickListener { startCall("audio") }
            binding.btnVideoCall.setOnClickListener { startCall("video") }
        }

        resolveOtherUserIfNeeded()
        observeMessages()

        lifecycleScope.launch {
            try {
                repository.markConversationRead(conversationId)
            } catch (e: Exception) {
            }
        }
    }

    private fun resolveOtherUserIfNeeded() {
        if (isGroup) return
        val myId = repository.currentUserId() ?: return
        lifecycleScope.launch {
            try {
                otherUserId = repository.getOtherParticipant(conversationId, myId)
            } catch (e: Exception) {
            }
        }
    }

    private fun observeMessages() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repository.pollMessages(conversationId).collect { messages ->
                    val shouldScroll = messages.size != lastMessageCount
                    lastMessageCount = messages.size
                    adapter.submit(messages)
                    if (shouldScroll && messages.isNotEmpty()) {
                        binding.recyclerMessages.scrollToPosition(messages.size - 1)
                    }
                    if (shouldScroll) {
                        try {
                            repository.markConversationRead(conversationId)
                        } catch (e: Exception) {
                        }
                    }
                }
            }
        }
    }

    private fun sendMessage(uid: String) {
        val text = binding.edtMessage.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return
        binding.edtMessage.setText("")

        // optimistic local echo so sending feels instant
        adapter.addLocal(Message(conversation_id = conversationId, sender_id = uid, content = text, created_at = null))
        binding.recyclerMessages.scrollToPosition(adapter.itemCount - 1)

        lifecycleScope.launch {
            try {
                repository.sendMessage(conversationId, uid, text)
            } catch (e: Exception) {
                Toast.makeText(this@ChatActivity, "Message failed to send. Check your connection.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startCall(type: String) {
        val target = otherUserId
        if (target == null) {
            Toast.makeText(this, "Still loading contact info, try again in a moment", Toast.LENGTH_SHORT).show()
            return
        }
        val name = binding.txtName.text.toString()
        val avatar = intent.getStringExtra(EXTRA_AVATAR)
        val intentToCall = android.content.Intent(this, InCallActivity::class.java).apply {
            putExtra(InCallActivity.EXTRA_OTHER_USER_ID, target)
            putExtra(InCallActivity.EXTRA_NAME, name)
            putExtra(InCallActivity.EXTRA_AVATAR, avatar)
            putExtra(InCallActivity.EXTRA_TYPE, type)
            putExtra(InCallActivity.EXTRA_CONVERSATION_ID, conversationId)
        }
        startActivity(intentToCall)
    }

    companion object {
        const val EXTRA_CONVERSATION_ID = "conversation_id"
        const val EXTRA_NAME = "name"
        const val EXTRA_AVATAR = "avatar"
        const val EXTRA_IS_GROUP = "is_group"
    }
}
