package com.techchat.messanger.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.techchat.messanger.R
import com.techchat.messanger.data.CallLogItem
import com.techchat.messanger.data.ChatRepository
import kotlinx.coroutines.launch

class CallsFragment : Fragment() {

    private val repository = ChatRepository()
    private lateinit var adapter: CallLogAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyState: View

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_calls, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val recycler = view.findViewById<RecyclerView>(R.id.recyclerCalls)
        swipeRefresh = view.findViewById(R.id.swipeRefresh)
        emptyState = view.findViewById(R.id.emptyState)

        adapter = CallLogAdapter(
            onRowClick = { startCall(it.other_user_id, it.other_name, it.other_avatar, it.call_type) },
            onCallBack = { startCall(it.other_user_id, it.other_name, it.other_avatar, it.call_type) }
        )
        recycler.layoutManager = LinearLayoutManager(requireContext())
        recycler.adapter = adapter
        swipeRefresh.setOnRefreshListener { load() }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val log = repository.getCallLog()
                adapter.submit(log)
                emptyState.visibility = if (log.isEmpty()) View.VISIBLE else View.GONE
            } catch (e: Exception) {
            } finally {
                swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun startCall(otherUserId: String, name: String, avatar: String?, type: String) {
        val intent = Intent(requireContext(), InCallActivity::class.java).apply {
            putExtra(InCallActivity.EXTRA_OTHER_USER_ID, otherUserId)
            putExtra(InCallActivity.EXTRA_NAME, name)
            putExtra(InCallActivity.EXTRA_AVATAR, avatar)
            putExtra(InCallActivity.EXTRA_TYPE, type)
        }
        startActivity(intent)
    }
}
