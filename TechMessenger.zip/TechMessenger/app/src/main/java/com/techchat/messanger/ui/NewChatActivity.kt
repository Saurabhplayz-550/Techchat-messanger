package com.techchat.messanger.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.techchat.messanger.data.ChatRepository
import com.techchat.messanger.data.Contact
import com.techchat.messanger.databinding.ActivityNewChatBinding
import kotlinx.coroutines.launch

class NewChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNewChatBinding
    private val repository = ChatRepository()
    private lateinit var adapter: ContactAdapter
    private var mode: String = MODE_CHAT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_CHAT
        binding.txtTitle.text = if (mode == MODE_GROUP) "New group" else "New chat"

        binding.btnBack.setOnClickListener { finish() }

        adapter = ContactAdapter(
            multiSelect = mode == MODE_GROUP,
            onClick = { contact -> startDirectChat(contact) },
            onSelectionChanged = { selected ->
                binding.txtSelectedCount.visibility = if (selected.isEmpty()) View.GONE else View.VISIBLE
                binding.txtSelectedCount.text = "${selected.size} selected"
                binding.fabNext.visibility = if (selected.isEmpty()) View.GONE else View.VISIBLE
            }
        )
        binding.recyclerContacts.layoutManager = LinearLayoutManager(this)
        binding.recyclerContacts.adapter = adapter

        binding.edtSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.fabNext.setOnClickListener { promptGroupNameAndCreate() }

        loadContacts()
    }

    private fun loadContacts() {
        lifecycleScope.launch {
            try {
                adapter.submit(repository.listContacts())
            } catch (e: Exception) {
                Toast.makeText(this@NewChatActivity, "Could not load contacts. Check your connection.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startDirectChat(contact: Contact) {
        lifecycleScope.launch {
            try {
                val convId = repository.getOrCreateDirectConversation(contact.id)
                val intent = Intent(this@NewChatActivity, ChatActivity::class.java).apply {
                    putExtra(ChatActivity.EXTRA_CONVERSATION_ID, convId)
                    putExtra(ChatActivity.EXTRA_NAME, contact.full_name ?: contact.username)
                    putExtra(ChatActivity.EXTRA_AVATAR, contact.avatar_url)
                    putExtra(ChatActivity.EXTRA_IS_GROUP, false)
                }
                startActivity(intent)
                finish()
            } catch (e: Exception) {
                Toast.makeText(this@NewChatActivity, "Could not start chat. Try again.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun promptGroupNameAndCreate() {
        val selected = adapter.selectedContacts()
        if (selected.isEmpty()) return

        val input = EditText(this).apply {
            hint = "Group name"
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this)
            .setTitle("Name your group")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text?.toString()?.trim().orEmpty()
                if (name.isEmpty()) {
                    Toast.makeText(this, "Group name can't be empty", Toast.LENGTH_SHORT).show()
                } else {
                    createGroup(name, selected)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun createGroup(name: String, members: List<Contact>) {
        lifecycleScope.launch {
            try {
                val convId = repository.createGroup(name, members.map { it.id })
                val intent = Intent(this@NewChatActivity, ChatActivity::class.java).apply {
                    putExtra(ChatActivity.EXTRA_CONVERSATION_ID, convId)
                    putExtra(ChatActivity.EXTRA_NAME, name)
                    putExtra(ChatActivity.EXTRA_IS_GROUP, true)
                }
                startActivity(intent)
                finish()
            } catch (e: Exception) {
                Toast.makeText(this@NewChatActivity, "Could not create group. Try again.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_CHAT = "chat"
        const val MODE_GROUP = "group"
    }
}
