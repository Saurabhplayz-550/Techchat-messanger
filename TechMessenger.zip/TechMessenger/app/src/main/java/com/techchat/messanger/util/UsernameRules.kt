package com.techchat.messanger.util

import android.text.InputFilter
import android.widget.EditText

/** Username rules shared by Signup and Edit profile. */
object UsernameRules {

    /** Blocks spaces (and any other whitespace) while typing AND when pasting. */
    private val noWhitespaceFilter = InputFilter { source, start, end, _, _, _ ->
        val cleaned = StringBuilder()
        for (i in start until end) {
            val ch = source[i]
            if (!ch.isWhitespace()) cleaned.append(ch)
        }
        // null = accept the input unchanged; otherwise return the cleaned text
        if (cleaned.length == end - start) null else cleaned.toString()
    }

    fun applyTo(field: EditText) {
        field.filters = field.filters + noWhitespaceFilter
    }

    fun hasWhitespace(username: String): Boolean = username.any { it.isWhitespace() }
}
