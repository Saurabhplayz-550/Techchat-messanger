package com.techchat.messanger.ui

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import coil.imageLoader
import com.techchat.messanger.data.AuthRepository
import com.techchat.messanger.data.ChatRepository
import com.techchat.messanger.databinding.ActivityInfoBinding
import kotlinx.coroutines.launch

/**
 * One generic "settings detail" screen reused for every row on the Profile
 * screen (Account, Privacy, Chats, Notifications, Storage and Data, Help),
 * so every button the mockup shows actually opens something real.
 */
class InfoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityInfoBinding
    private lateinit var prefs: SharedPreferences
    private val authRepository = AuthRepository()
    private val repository = ChatRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInfoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = getSharedPreferences("tech_messenger_prefs", MODE_PRIVATE)

        binding.btnBack.setOnClickListener { finish() }

        when (intent.getStringExtra(EXTRA_TOPIC)) {
            "account" -> buildAccount()
            "privacy" -> buildPrivacy()
            "chats" -> buildChats()
            "notifications" -> buildNotifications()
            "storage" -> buildStorage()
            "help" -> buildHelp()
            else -> finish()
        }
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(0xFF6B7280.toInt())
        setPadding(4, 28, 4, 8)
    }

    private fun bodyText(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(0xFF1A1A1A.toInt())
        setPadding(4, 4, 4, 4)
    }

    private fun switchRow(label: String, key: String, default: Boolean): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 20, 4, 20)
        }
        val txt = TextView(this).apply {
            text = label
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val sw = Switch(this).apply {
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _: CompoundButton, checked: Boolean ->
                prefs.edit().putBoolean(key, checked).apply()
            }
        }
        row.addView(txt)
        row.addView(sw)
        return row
    }

    private fun buildAccount() {
        binding.txtTitle.text = "Account"
        binding.container.addView(sectionTitle("EMAIL"))
        binding.container.addView(bodyText(authRepository.currentUserEmail() ?: "—"))
        binding.container.addView(sectionTitle("SECURITY"))
        binding.container.addView(bodyText("Sign-in is email + password only. Change your password by signing out and using \"Forgot password\" on the login screen."))
        binding.container.addView(sectionTitle("DANGER ZONE"))
        val logout = TextView(this).apply {
            text = "Log out of Tech Messenger"
            setTextColor(0xFFE53935.toInt())
            textSize = 15f
            setPadding(4, 20, 4, 20)
            setOnClickListener {
                lifecycleScope.launch {
                    authRepository.signOut()
                    startActivity(Intent(this@InfoActivity, LoginActivity::class.java))
                    finishAffinity()
                }
            }
        }
        binding.container.addView(logout)
    }

    private fun buildPrivacy() {
        binding.txtTitle.text = "Privacy"
        binding.container.addView(sectionTitle("WHO CAN SEE MY INFO"))
        binding.container.addView(switchRow("Show read receipts", "privacy_read_receipts", true))
        binding.container.addView(switchRow("Show last seen", "privacy_last_seen", true))
        binding.container.addView(switchRow("Show profile photo to everyone", "privacy_photo_public", true))
        binding.container.addView(sectionTitle("ABOUT"))
        binding.container.addView(bodyText("These preferences are saved on this device. Messages are only ever visible to people in the conversation, enforced by row-level security in the backend."))
    }

    private fun buildChats() {
        binding.txtTitle.text = "Chats"
        binding.container.addView(sectionTitle("DISPLAY"))
        binding.container.addView(switchRow("Enter is send (hardware keyboard)", "chats_enter_send", false))
        binding.container.addView(switchRow("Media auto-download", "chats_auto_download", true))
        binding.container.addView(sectionTitle("CHAT HISTORY"))
        val exportRow = TextView(this).apply {
            text = "Chat history stays on the server tied to your account. Uninstalling the app never deletes your conversations."
            textSize = 14f
            setPadding(4, 8, 4, 8)
        }
        binding.container.addView(exportRow)
    }

    private fun buildNotifications() {
        binding.txtTitle.text = "Notifications"
        binding.container.addView(sectionTitle("MESSAGES"))
        binding.container.addView(switchRow("Show notifications", "notif_messages", true))
        binding.container.addView(switchRow("Notification sound", "notif_sound", true))
        binding.container.addView(sectionTitle("GROUPS"))
        binding.container.addView(switchRow("Show notifications", "notif_groups", true))
        binding.container.addView(sectionTitle("CALLS"))
        binding.container.addView(switchRow("Ringtone", "notif_calls", true))
    }

    private fun buildStorage() {
        binding.txtTitle.text = "Storage and Data"
        binding.container.addView(sectionTitle("STORAGE"))
        val cacheLine = bodyText("Calculating image cache…")
        binding.container.addView(cacheLine)
        lifecycleScope.launch {
            val size = try {
                imageLoader.diskCache?.size ?: 0L
            } catch (e: Exception) {
                0L
            }
            cacheLine.text = "Image cache: ${formatBytes(size)}"
        }
        val clearBtn = TextView(this).apply {
            text = "Clear image cache"
            setTextColor(0xFF1E88E5.toInt())
            textSize = 15f
            setPadding(4, 24, 4, 4)
            setOnClickListener {
                imageLoader.diskCache?.clear()
                imageLoader.memoryCache?.clear()
                Toast.makeText(this@InfoActivity, "Cache cleared", Toast.LENGTH_SHORT).show()
                recreate()
            }
        }
        binding.container.addView(clearBtn)
        binding.container.addView(sectionTitle("NETWORK"))
        binding.container.addView(switchRow("Use less data for calls", "storage_low_data", false))
    }

    private fun buildHelp() {
        binding.txtTitle.text = "Help"
        binding.container.addView(sectionTitle("FAQ"))
        binding.container.addView(bodyText("• Chats sync every few seconds automatically.\n• Calls in this build are simulated — no real audio/video is sent yet.\n• Statuses disappear 24 hours after posting."))
        binding.container.addView(sectionTitle("CONTACT"))
        val contact = TextView(this).apply {
            text = "Email support"
            setTextColor(0xFF1E88E5.toInt())
            textSize = 15f
            setPadding(4, 20, 4, 4)
            setOnClickListener {
                val email = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
                    putExtra(Intent.EXTRA_SUBJECT, "Tech Messenger support")
                }
                try {
                    startActivity(email)
                } catch (e: Exception) {
                    Toast.makeText(this@InfoActivity, "No email app found", Toast.LENGTH_SHORT).show()
                }
            }
        }
        binding.container.addView(contact)
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format("%.1f KB", kb)
        val mb = kb / 1024.0
        return String.format("%.1f MB", mb)
    }

    companion object {
        const val EXTRA_TOPIC = "topic"
    }
}
