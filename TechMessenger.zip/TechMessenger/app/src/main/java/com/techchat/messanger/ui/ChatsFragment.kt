package com.techchat.messanger.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.recyclerview.widget.RecyclerView
import com.techchat.messanger.R
import com.techchat.messanger.data.ChatListItem
import com.techchat.messanger.data.ChatRepository
import kotlinx.coroutines.launch

/** Base for Chats/Groups tabs: both list conversations, filtered by group flag. */
abstract class BaseChatListFragment(private val wantGroups: Boolean) : Fragment() {

    protected val repository = ChatRepository()
    protected lateinit var adapter: ChatListAdapter
    private lateinit var recycler: RecyclerView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyState: View

    abstract fun layoutRes(): Int
    abstract fun recyclerId(): Int
    abstract fun swipeRefreshId(): Int
    abstract fun emptyStateId(): Int

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(layoutRes(), container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        recycler = view.findViewById(recyclerId())
        swipeRefresh = view.findViewById(swipeRefreshId())
        emptyState = view.findViewById(emptyStateId())

        adapter = ChatListAdapter { item -> openChat(item) }
        recycler.layoutManager = LinearLayoutManager(requireContext())
        recycler.adapter = adapter

        swipeRefresh.setOnRefreshListener { refreshOnce() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                repository.pollChatList().collect { list ->
                    val filtered = list.filter { it.is_group == wantGroups }
                    adapter.submit(filtered)
                    emptyState.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
                    swipeRefresh.isRefreshing = false
                }
            }
        }
    }

    private fun refreshOnce() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val list = repository.getChatList().filter { it.is_group == wantGroups }
                adapter.submit(list)
                emptyState.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            } catch (_: Exception) {
            } finally {
                swipeRefresh.isRefreshing = false
            }
        }
    }

    fun filter(query: String) = adapter.filter(query)

    private fun openChat(item: ChatListItem) {
        val intent = Intent(requireContext(), ChatActivity::class.java).apply {
            putExtra(ChatActivity.EXTRA_CONVERSATION_ID, item.conversation_id)
            putExtra(ChatActivity.EXTRA_NAME, item.display_name)
            putExtra(ChatActivity.EXTRA_AVATAR, item.display_avatar)
            putExtra(ChatActivity.EXTRA_IS_GROUP, item.is_group)
        }
        startActivity(intent)
    }
}

class ChatsFragment : BaseChatListFragment(wantGroups = false) {
    override fun layoutRes() = R.layout.fragment_chats
    override fun recyclerId() = R.id.recyclerChats
    override fun swipeRefreshId() = R.id.swipeRefresh
    override fun emptyStateId() = R.id.emptyState
}

class GroupsFragment : BaseChatListFragment(wantGroups = true) {
    override fun layoutRes() = R.layout.fragment_groups
    override fun recyclerId() = R.id.recyclerGroups
    override fun swipeRefreshId() = R.id.swipeRefresh
    override fun emptyStateId() = R.id.emptyState
}
