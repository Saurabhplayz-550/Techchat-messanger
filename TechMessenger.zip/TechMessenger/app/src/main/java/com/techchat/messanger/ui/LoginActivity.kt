package com.techchat.messanger.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.techchat.messanger.data.AuthRepository
import com.techchat.messanger.data.AuthResult
import com.techchat.messanger.databinding.ActivityLoginBinding
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val authRepository = AuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.txtCreateAccount.setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
        }

        binding.btnLogin.setOnClickListener { attemptLogin() }
    }

    private fun attemptLogin() {
        val identifier = binding.edtIdentifier.text?.toString()?.trim().orEmpty()
        val password = binding.edtPassword.text?.toString().orEmpty()

        if (identifier.isEmpty() || password.isEmpty()) {
            showError("Please fill in both fields")
            return
        }

        setLoading(true)
        lifecycleScope.launch {
            when (val result = authRepository.login(identifier, password)) {
                is AuthResult.Success -> {
                    setLoading(false)
                    startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
                    finish()
                }
                is AuthResult.Failure -> {
                    setLoading(false)
                    showError(result.message)
                }
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progress.visibility = if (loading) android.view.View.VISIBLE else android.view.View.GONE
        binding.btnLogin.isEnabled = !loading
    }

    private fun showError(message: String) {
        binding.txtError.text = message
        binding.txtError.visibility = android.view.View.VISIBLE
    }
}
