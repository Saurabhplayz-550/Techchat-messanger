# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keepclassmembers class com.techchat.messanger.data.** { *; }
